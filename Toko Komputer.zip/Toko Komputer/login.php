<?php
@ob_start();
session_start();
if (isset($_POST['proses'])) {
    require 'config.php';

    $user = strip_tags($_POST['user']);
    $pass = strip_tags($_POST['pass']);

    $sql = 'select member.*, login.user, login.pass
            from member inner join login on member.id_member = login.id_member
            where user =? and pass = md5(?)';
    $row = $config->prepare($sql);
    $row->execute(array($user, $pass));
    $jum = $row->rowCount();
    if ($jum > 0) {
        $hasil = $row->fetch();
        $_SESSION['admin'] = $hasil;
        echo '<script>alert("Login Sukses");window.location="index.php"</script>';
    } else {
        echo '<script>alert("Login Gagal");history.go(-1);</script>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!-- Custom styles -->
    <style>
        body {
            background-image: url('Baground/Leptop.jpg');
            background-size: cover;
            background-position: center;
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Arial', sans-serif;
            position: relative;
        }
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7); /* Overlay gelap */
            z-index: 1;
        }
        .form-login {
            position: relative;
            z-index: 2;
            background: rgba(255, 255, 255, 0.1); /* Transparansi form */
            padding: 20px;
            border-radius: 8px;
            width: 100%;
            max-width: 400px;
            text-align: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        }
        .form-login h2 {
            margin-bottom: 20px;
            font-size: 30px;
            color: #fff; /* Warna teks putih */
            font-weight: bold;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.7); /* Efek bayangan pada teks */
        }
        .form-control {
            background: rgba(255, 255, 255, 0.2); /* Transparansi input */
            border: none;
            color: #fff;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.5);
        }
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7); /* Transparansi placeholder */
        }
        .btn {
            background: #00bcd4; /* Warna tombol biru */
            border: none;
            color: #fff;
            padding: 10px;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .btn:hover {
            background: #008c9e; /* Warna tombol saat hover */
        }
        .register-link {
            color: #fff; /* Warna teks putih */
            margin-top: 10px;
            display: block;
            font-size: 14px;
            text-decoration: none;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.7); /* Efek bayangan pada teks */
        }
        .register-link:hover {
            color: #00bcd4; /* Warna teks saat hover */
        }
    </style>
  </head>

  <body>
      <div class="form-login">
          <form method="POST">
              <h2>Login</h2>
              <input type="text" class="form-control" name="user" placeholder="User ID" autofocus>
              <input type="password" class="form-control" name="pass" placeholder="Password">
              <button class="btn btn-block" name="proses" type="submit"><i class="fa fa-lock"></i> SIGN IN</button>
          </form>
          <!-- Link ke halaman register -->
          <a href="register.php" class="register-link">Register</a>
      </div>
  </body>
</html>
