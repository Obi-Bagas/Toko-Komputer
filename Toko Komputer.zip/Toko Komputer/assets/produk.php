<div class="container">
  <h2>Daftar Produk</h2>
  <p>Ini adalah halaman produk.</p>
  <ul>
    <li>Produk A</li>
    <li>Produk B</li>
    <li>Produk C</li>
  </ul>
</div>
